package xyz.mpv.rex.utils.media

/**
 * Turns a release-style file name into what the player's top bar shows:
 * a clean title, and below it the season and episode when there are any.
 *
 *   Daredevil.Born.Again.S02E04.Gloves.Off.1080p.WEB-DL.x265.6CH-Pahe.in
 *     -> title "Daredevil Born Again", subtitle "S02E04"
 *   The.Dark.Knight.2008.1080p.BluRay.x264
 *     -> title "The Dark Knight", subtitle "2008"
 *
 * It uses the same [MediaInfoParser] as online subtitle search, so what the top bar shows is
 * exactly what the search sheet looks for. Titles that do not look like release names (a
 * YouTube title, a hand-written file name) are left untouched.
 */
object PlayerTitleFormatter {
  data class Display(
    val title: String,
    val subtitle: String? = null,
  )

  // Tags that only appear in release file names.
  private val RELEASE_TAGS = Regex(
    """(?<![A-Za-z0-9])(?:\d{3,4}[pi]|4k|x26[45]|h\.?26[45]|hevc|web[-. ]?dl|webrip|bluray|brrip|bdrip|hdtv|dvdrip|remux)(?![A-Za-z0-9])""",
    RegexOption.IGNORE_CASE,
  )

  // "Inception (2010)" or "Inception [2010]": the standard media-library naming for movies.
  private val YEAR_IN_BRACKETS = Regex("""[(\[](?:19|20)\d{2}[)\]]""")

  /**
   * A title is only rewritten when it looks like a release or library file name, so ordinary
   * titles ("Best of 2023 Highlights", a YouTube title) are never mangled:
   *  - it has a season/episode marker, or
   *  - it carries a release tag (1080p, x265, WEB-DL, ...), or
   *  - it has a year and is either dot/underscore separated (scene style) or the year is in
   *    brackets (library style).
   */
  private fun looksLikeRelease(raw: String, info: ParsedMediaInfo): Boolean {
    if (info.season != null || info.episode != null) return true
    if (RELEASE_TAGS.containsMatchIn(raw)) return true
    if (info.year == null) return false
    if (YEAR_IN_BRACKETS.containsMatchIn(raw)) return true
    return !raw.contains(' ') && (raw.contains('.') || raw.contains('_'))
  }

  fun format(raw: String): Display {
    if (raw.isBlank() || raw.startsWith("http://") || raw.startsWith("https://")) {
      return Display(raw)
    }

    val info = MediaInfoParser.parse(raw)
    if (!looksLikeRelease(raw, info)) return Display(raw)
    // The parser can strip a whole title away (a movie literally named "2012"): keep the original.
    if (info.title.isBlank()) return Display(raw)

    val subtitle = when {
      // Series: season and episode below the title.
      info.season != null || info.episode != null -> buildString {
        info.season?.let { append("S").append(it.toString().padStart(2, '0')) }
        info.episode?.let { append("E").append(it.toString().padStart(2, '0')) }
      }
      // Movies: the release year below the title, the counterpart of S02E04 for series.
      else -> info.year
    }
    return Display(info.title, subtitle)
  }
}
