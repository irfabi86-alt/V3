package xyz.mpv.rex.ui.browser.selection

import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.runtime.Composable
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import xyz.mpv.rex.domain.media.model.Video
import xyz.mpv.rex.ui.player.PlayerActivity
import xyz.mpv.rex.utils.media.MediaUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * Manager for handling item selection and operations in browser screens
 */
@Stable
class SelectionManager<T, ID>(
  private val items: () -> List<T>,
  private val getId: (T) -> ID,
  private val context: Context,
  private val scope: CoroutineScope,
  private val onDeleteItems: suspend (List<T>, Boolean) -> Pair<Int, Int>,
  private val onRenameItem: (suspend (T, String) -> Result<Unit>)?,
  private val onOperationComplete: () -> Unit,
) {
  var state by mutableStateOf(SelectionState<ID>())
    private set

  val isInSelectionMode: Boolean
    get() = state.isInSelectionMode

  val selectedCount: Int
    get() = state.selectedCount

  val isSingleSelection: Boolean
    get() = state.isSingleSelection

  /**
   * Toggle selection of an item
   */
  fun toggle(item: T) {
    state = state.toggle(getId(item))
  }

  /**
   * Perform range selection from the last selected item to the specified item
   */
  fun toggleRange(item: T) {
    val allIds = items().map(getId)
    state = state.selectRange(getId(item), allIds)
  }

  /**
   * Handle long-click event on an item.
   * If in selection mode, triggers range selection.
   * Otherwise, starts selection mode by toggling the item.
   */
  fun handleLongClick(item: T) {
    if (isInSelectionMode) {
      toggleRange(item)
    } else {
      toggle(item)
    }
  }

  /**
   * Clear all selections
   */
  fun clear() {
    state = state.clear()
  }

  /**
   * Select all items
   */
  fun selectAll() {
    state = state.selectAll(items().map(getId))
  }

  /**
   * Invert selection
   */
  fun invertSelection() {
    state = state.invertSelection(items().map(getId))
  }

  /**
   * Check if an item is selected
   */
  fun isSelected(item: T): Boolean = state.isSelected(getId(item))

  /**
   * Get currently selected items
   */
  fun getSelectedItems(): List<T> = state.getSelected(items(), getId)

  /**
   * Delete selected items directly (using MANAGE_EXTERNAL_STORAGE permission)
   */
  fun deleteSelected(deleteFiles: Boolean = false) {
    val selected = getSelectedItems()
    if (selected.isEmpty()) return

    scope.launch {
      runCatching {
        val (deleted, failed) = onDeleteItems(selected, deleteFiles)
        if (deleted > 0) {
          Toast.makeText(context, "Deleted successfully", Toast.LENGTH_SHORT).show()
        } else if (failed > 0) {
          Toast.makeText(context, "Failed to delete", Toast.LENGTH_SHORT).show()
        }
      }.onFailure {
        Toast.makeText(context, "Failed to delete: ${it.message}", Toast.LENGTH_SHORT).show()
      }
      clear()
      onOperationComplete()
    }
  }

  /**
   * Rename the selected item (only works with single selection)
   */
  fun renameSelected(newName: String) {
    if (!isSingleSelection || onRenameItem == null) return

    val item = getSelectedItems().firstOrNull() ?: return

    scope.launch {
      runCatching {
        val result = onRenameItem(item, newName)
        result.onSuccess {
          Toast.makeText(context, "Renamed successfully", Toast.LENGTH_SHORT).show()
        }.onFailure { error ->
          Toast.makeText(context, "Failed to rename: ${error.message}", Toast.LENGTH_SHORT).show()
        }
      }.onFailure {
        Toast.makeText(context, "Failed to rename: ${it.message}", Toast.LENGTH_SHORT).show()
      }
      clear()
      onOperationComplete()
    }
  }

  /**
   * Share selected items (only for videos)
   */
  fun shareSelected() {
    val selected = getSelectedItems()
    if (selected.isEmpty() || selected.first() !is Video) return

    @Suppress("UNCHECKED_CAST")
    val videos = selected as List<Video>
    MediaUtils.shareVideos(context, videos)
  }

  /**
   * Play selected items as a playlist (only for videos)
   */
  fun playSelected() {
    val selected = getSelectedItems()
    if (selected.isEmpty() || selected.first() !is Video) return

    @Suppress("UNCHECKED_CAST")
    val videos = selected as List<Video>

    if (videos.size == 1) {
      // Single video - play normally
      MediaUtils.playFile(videos.first(), context)
    } else {
      // Multiple videos - play as playlist
      MediaUtils.playPlaylist(videos, 0, context)
    }

    // Clear selection after starting playback
    clear()
  }

  /** Plays selected video/audio files in selection order using the bottom mini player. */
  fun playSelectedInMiniPlayer() {
    val selected = getSelectedItems()
    if (selected.isEmpty() || selected.first() !is Video) return

    @Suppress("UNCHECKED_CAST")
    MediaUtils.playInMiniPlayer(selected as List<Video>)
    clear()
  }
}

/**
 * Composable function to remember a SelectionManager
 *
 * @param items List of items to manage selection for
 * @param getId Function to extract ID from an item
 * @param onDeleteItems Callback to delete items (includes boolean to delete original files)
 * @param onRenameItem Optional callback to rename an item
 * @param onOperationComplete Callback when an operation completes (to refresh list)
 */
@Composable
fun <T, ID> rememberSelectionManager(
  items: List<T>,
  getId: (T) -> ID,
  onDeleteItems: suspend (List<T>, Boolean) -> Pair<Int, Int>,
  onRenameItem: (suspend (T, String) -> Result<Unit>)? = null,
  onOperationComplete: () -> Unit = {},
): SelectionManager<T, ID> {
  val context = LocalContext.current
  val scope = rememberCoroutineScope()

  val currentItemsState = rememberUpdatedState(items)
  val currentGetIdState = rememberUpdatedState(getId)
  val currentOnDeleteItemsState = rememberUpdatedState(onDeleteItems)
  val currentOnRenameItemState = rememberUpdatedState(onRenameItem)
  val currentOnOperationCompleteState = rememberUpdatedState(onOperationComplete)

  return remember {
    SelectionManager(
      items = { currentItemsState.value },
      getId = { currentGetIdState.value(it) },
      context = context,
      scope = scope,
      onDeleteItems = { list, delete -> currentOnDeleteItemsState.value(list, delete) },
      onRenameItem = { item, name ->
        currentOnRenameItemState.value?.invoke(item, name)
          ?: Result.failure(IllegalStateException("Rename not supported"))
      },
      onOperationComplete = { currentOnOperationCompleteState.value() },
    )
  }
}
