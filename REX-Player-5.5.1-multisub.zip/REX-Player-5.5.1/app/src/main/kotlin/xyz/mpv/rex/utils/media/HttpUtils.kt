package xyz.mpv.rex.utils.media

import android.net.Uri
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLDecoder

object HttpUtils {
  private const val TAG = "HttpUtils"
  private const val CONNECTION_TIMEOUT = 3000
  private const val READ_TIMEOUT = 3000

  suspend fun extractFilenameFromUrl(url: String): String? = withContext(Dispatchers.IO) {
    try {
      val uri = Uri.parse(url)
      val filenameFromHeaders = getFilenameFromHttpHeaders(url)
      if (filenameFromHeaders != null) {
        Log.d(TAG, "Extracted filename from headers: $filenameFromHeaders")
        return@withContext filenameFromHeaders
      }
      val filenameFromUrl = extractFilenameFromUrlPath(uri)
      Log.d(TAG, "Extracted filename from URL: $filenameFromUrl")
      return@withContext filenameFromUrl
    } catch (e: Exception) {
      Log.e(TAG, "Error extracting filename: ${e.message}")
      null
    }
  }

  private fun getFilenameFromHttpHeaders(url: String): String? {
    var connection: HttpURLConnection? = null
    try {
      connection = URL(url).openConnection() as HttpURLConnection
      connection.requestMethod = "HEAD"
      connection.connectTimeout = CONNECTION_TIMEOUT
      connection.readTimeout = READ_TIMEOUT
      connection.setRequestProperty("User-Agent", "mpvex/1.0")
      connection.instanceFollowRedirects = true
      connection.connect()

      val responseCode = connection.responseCode
      if (responseCode != HttpURLConnection.HTTP_OK && responseCode != HttpURLConnection.HTTP_PARTIAL) {
        Log.w(TAG, "HTTP response: $responseCode")
      }

      connection.getHeaderField("Content-Disposition")?.let {
        parseContentDisposition(it)?.let { filename -> return filename }
      }

      connection.getHeaderField("Content-Location")?.let {
        return extractFilenameFromUrlPath(Uri.parse(it))
      }

      return null
    } catch (e: IOException) {
      Log.e(TAG, "IO error: ${e.message}")
      return null
    } catch (e: Exception) {
      Log.e(TAG, "Error: ${e.message}")
      return null
    } finally {
      connection?.disconnect()
    }
  }

  /**
   * Fast HEAD probe to determine if an unknown URL points to an HTML web page
   * (which needs an extractor like yt-dlp) vs a direct media stream (which MPV plays natively).
   */
  suspend fun probeIsHtmlWebPage(url: String): Boolean = withContext(Dispatchers.IO) {
    var connection: HttpURLConnection? = null
    try {
      connection = URL(url).openConnection() as HttpURLConnection
      connection.requestMethod = "HEAD"
      connection.connectTimeout = 1500
      connection.readTimeout = 1500
      connection.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36")
      connection.instanceFollowRedirects = true
      connection.connect()

      val contentType = connection.contentType?.lowercase() ?: return@withContext false
      contentType.contains("text/html") || contentType.contains("application/xhtml+xml")
    } catch (e: Exception) {
      Log.d(TAG, "probeIsHtmlWebPage probe failed for $url: ${e.message}")
      false
    } finally {
      connection?.disconnect()
    }
  }

  private fun parseContentDisposition(contentDisposition: String): String? {
    try {
      val filenameStarPattern = Regex("""filename\*=(?:UTF-8|utf-8)?''?"?([^";\r\n]+)"?""", RegexOption.IGNORE_CASE)
      filenameStarPattern.find(contentDisposition)?.let { match ->
        val encodedFilename = match.groupValues[1]
        return try {
          URLDecoder.decode(encodedFilename, "UTF-8")
        } catch (e: Exception) {
          encodedFilename
        }
      }

      val filenamePattern = Regex("""filename="?([^";\r\n]+)"?""", RegexOption.IGNORE_CASE)
      filenamePattern.find(contentDisposition)?.let { match ->
        return match.groupValues[1].trim()
      }

      return null
    } catch (e: Exception) {
      Log.e(TAG, "Error parsing Content-Disposition: ${e.message}")
      return null
    }
  }

  private fun extractFilenameFromUrlPath(uri: Uri): String {
    val path = uri.path ?: return uri.host ?: "Network Stream"
    val lastSegment = path.substringAfterLast("/")

    if (lastSegment.isNotBlank()) {
      return try {
        URLDecoder.decode(lastSegment, "UTF-8")
          .substringBefore("?")
          .substringBefore("#")
          .takeIf { it.isNotBlank() } ?: uri.host ?: "Network Stream"
      } catch (e: Exception) {
        lastSegment.substringBefore("?").substringBefore("#")
      }
    }

    return uri.host ?: "Network Stream"
  }

  val directMediaExtensions =
    setOf(
      "mp4", "m4v", "mkv", "webm", "avi", "mov", "wmv", "flv", "ts", "m2ts",
      "mp3", "m4a", "aac", "flac", "wav", "ogg", "opus", "m3u", "m3u8", "mpd",
      "3gp", "3g2", "ogv", "f4v", "vob", "rmvb", "rm", "asf", "divx", "m2v",
      "mpg", "mpeg", "m4b", "m4p", "oga", "spx", "wma", "wv", "ape"
    )

  fun isNetworkStream(uri: Uri?): Boolean {
    if (uri == null) return false
    val scheme = uri.scheme?.lowercase()
    return scheme in listOf("http", "https", "rtmp", "rtmps", "rtsp", "rtsps", "mms", "mmsh", "ftp", "ftps")
  }

  fun isDirectMediaUrl(uri: Uri?): Boolean {
    if (uri == null || !isNetworkStream(uri)) return false

    val scheme = uri.scheme?.lowercase()
    if (scheme in listOf("rtmp", "rtmps", "rtsp", "rtsps", "mms", "mmsh", "ftp", "ftps")) {
      return true
    }

    val host = uri.host?.lowercase().orEmpty()
    if (host.endsWith(".googlevideo.com") || host == "googlevideo.com") {
      return true
    }

    val path = uri.path?.lowercase().orEmpty()
    val lastSegment = uri.lastPathSegment?.substringAfterLast('/')?.let(Uri::decode)?.lowercase().orEmpty()
    val fullUrl = uri.toString().lowercase()

    val extension = lastSegment.substringAfterLast('.', "")
    if (extension in directMediaExtensions) return true

    for (mediaExt in directMediaExtensions) {
      if (path.contains(".$mediaExt") || fullUrl.contains(".$mediaExt?") || fullUrl.contains(".$mediaExt#") || fullUrl.endsWith(".$mediaExt")) {
        return true
      }
    }
    return false
  }

  /**
   * Extracts the referer domain from a Uri.
   * Returns the full origin (scheme + host + port) to be used as Referer header.
   * 
   * @param uri The Uri to extract the referer from
   * @return The referer origin string, or null if extraction fails
   */
  fun extractRefererDomain(uri: Uri?): String? {
    if (uri == null) return null
    
    return try {
      val scheme = uri.scheme ?: return null
      val host = uri.host ?: return null
      val port = uri.port
      
      // Build the referer origin
      if (port != -1 && port != 80 && port != 443) {
        // Include non-standard port
        "$scheme://$host:$port"
      } else {
        // Standard port or no port specified
        "$scheme://$host"
      }
    } catch (e: Exception) {
      Log.e(TAG, "Error extracting referer domain: ${e.message}")
      null
    }
  }
}
