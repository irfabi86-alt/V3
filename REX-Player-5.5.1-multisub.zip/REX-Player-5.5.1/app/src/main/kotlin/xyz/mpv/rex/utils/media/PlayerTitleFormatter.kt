package xyz.mpv.rex.utils.media

/**
 * Turns a release-style file name into what the player's top bar shows.
 *
 * Series: "Series name: Episode title" on the first line, "(S02E04)" below it.
 *   Daredevil.Born.Again.S02E04.Gloves.Off.1080p.WEB-DL.x265.6CH-Pahe.in
 *     -> "Daredevil Born Again: Gloves Off" / "(S02E04)"
 * Movies: the clean title, with the year below it.
 *   The.Dark.Knight.2008.1080p.BluRay.x264
 *     -> "The Dark Knight" / "2008"
 *
 * It uses the same [MediaInfoParser] as online subtitle search, so what the top bar shows is
 * exactly what the search sheet looks for. Titles that do not look like release names (a
 * YouTube title, a hand-written file name) are left untouched.
 */
object PlayerTitleFormatter {
  data class Display(
    val title: String,
    val subtitle: String? = null,
  )

  // Tags that only appear in release file names.
  private val RELEASE_TAGS = Regex(
    """(?<![A-Za-z0-9])(?:\d{3,4}[pi]|4k|x26[45]|h\.?26[45]|hevc|web[-. ]?dl|webrip|bluray|brrip|bdrip|hdtv|dvdrip|remux)(?![A-Za-z0-9])""",
    RegexOption.IGNORE_CASE,
  )

  // "Inception (2010)" or "Inception [2010]": the standard media-library naming for movies.
  private val YEAR_IN_BRACKETS = Regex("""[(\[](?:19|20)\d{2}[)\]]""")

  /**
   * A title is only rewritten when it looks like a release or library file name, so ordinary
   * titles ("Best of 2023 Highlights", a YouTube title) are never mangled:
   *  - it has a season/episode marker, or
   *  - it carries a release tag (1080p, x265, WEB-DL, ...), or
   *  - it has a year and is either dot/underscore separated (scene style) or the year is in
   *    brackets (library style).
   */
  private fun looksLikeRelease(raw: String, info: ParsedMediaInfo): Boolean {
    if (info.season != null || info.episode != null) return true
    if (RELEASE_TAGS.containsMatchIn(raw)) return true
    if (info.year == null) return false
    if (YEAR_IN_BRACKETS.containsMatchIn(raw)) return true
    return !raw.contains(' ') && (raw.contains('.') || raw.contains('_'))
  }

  fun format(raw: String): Display {
    if (raw.isBlank() || raw.startsWith("http://") || raw.startsWith("https://")) {
      return Display(raw)
    }

    val info = MediaInfoParser.parse(raw)
    if (!looksLikeRelease(raw, info)) return Display(raw)
    // The parser can strip a whole title away (a movie literally named "2012"): keep the original.
    if (info.title.isBlank()) return Display(raw)

    val isSeries = info.season != null || info.episode != null
    if (isSeries) {
      val episodeTitle = extractEpisodeTitle(raw)
      val title = if (episodeTitle != null) "${info.title}: $episodeTitle" else info.title
      val marker = buildString {
        append("(")
        info.season?.let { append("S").append(it.toString().padStart(2, '0')) }
        info.episode?.let { append("E").append(it.toString().padStart(2, '0')) }
        append(")")
      }
      return Display(title, marker)
    }

    // Movies: the release year below the title, the counterpart of (S02E04) for series.
    return Display(info.title, info.year)
  }

  // ==================== Episode title ====================

  // S02E04, also S02E04E05 / S02E04-E05 for multi-episode files, and 2x04.
  private val EPISODE_MARKER = Regex(
    """(?:[Ss]\d{1,2}[Ee]\d{1,4}(?:[-]?[Ee]\d{1,4})*|(?<![A-Za-z0-9])\d{1,2}[xX]\d{1,4}(?![A-Za-z0-9]))""",
  )

  // "Show - 01 - Episode title (1080p)": the layout fansub groups use.
  private val DASH_EPISODE = Regex("""\s-\s\d{1,4}\s-\s(.+)""")

  // Where the episode title ends: the first resolution, source, codec, audio or service tag,
  // or an opening bracket. Short ambiguous words (MAX, NF, WEB, DV) are deliberately not here,
  // so an episode called "Web of Lies" is not cut. The resolution almost always comes first.
  private val TITLE_STOP = Regex(
    """(?<![A-Za-z0-9])(?:\d{3,4}[pi]|4k|uhd|x26[45]|h\.?26[45]|hevc|avc|web[-. ]?dl|webrip|bluray|brrip|bdrip|hdtv|dvdrip|remux|dsnp|amzn|atvp|hmax|pcok|ddp?\+?\d*|aac\d*|atmos|ac3|eac3|dts|truehd|flac|10bit|repack|proper|\d[Cc][Hh])(?![A-Za-z0-9])|[\[(]""",
    RegexOption.IGNORE_CASE,
  )

  /** The episode's own title ("Gloves Off"), or null when the file name does not carry one. */
  private fun extractEpisodeTitle(raw: String): String? {
    val dash = DASH_EPISODE.find(raw)
    val tail = if (dash != null) {
      dash.groupValues[1]
    } else {
      val marker = EPISODE_MARKER.find(raw) ?: return null
      raw.substring(marker.range.last + 1)
    }

    val cut = TITLE_STOP.find(tail)?.range?.first ?: tail.length
    val title = tail.substring(0, cut)
      .replace('.', ' ')
      .replace('_', ' ')
      .replace(Regex("""\s+"""), " ")
      .trim(' ', '-', '\u2013', '\u2014', ':')

    // Nothing left, or too long to be a title (an unrecognised tag run): better no title at all.
    return title.takeIf { it.isNotBlank() && it.length <= 60 }
  }
}
