package xyz.mpv.rex.database.repository

import android.content.Context
import android.net.Uri
import android.util.Log
import xyz.mpv.rex.database.dao.VideoMetadataDao
import xyz.mpv.rex.database.entities.VideoMetadataEntity
import xyz.mpv.rex.domain.media.model.Video
import xyz.mpv.rex.utils.media.MediaInfoOps
import xyz.mpv.rex.utils.media.MediaInfoOps.VideoMetadata
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.math.pow

/**
 * Repository for caching video metadata with parallel processing support
 * Provides progressive loading and batch processing capabilities
 */
class VideoMetadataCacheRepository(
  private val context: Context,
  private val dao: VideoMetadataDao,
) {
  companion object {
    private const val TAG = "VideoMetadataCache"
    private const val PARALLEL_PROCESSING_LIMIT = 16 // Process 16 videos simultaneously for faster extraction
    private const val CACHE_VALIDITY_DAYS = 30L
    private const val RETRIEVER_SAFE_WIDTH = 4096
  }

  /**
   * Extracts a single metadata row using MediaInfo, never throwing.
   * Shared by the batch path and [walkMetadata] so both write identical cache rows.
   */
  private suspend fun extractAndCache(
    file: File,
    uri: Uri,
    displayName: String,
  ): MediaInfoOps.VideoMetadata? {
    val result = MediaInfoOps.extractBasicMetadata(context, uri, displayName)
    result.onSuccess { metadata ->
      dao.insertMetadata(
        VideoMetadataEntity(
          path = file.absolutePath,
          size = file.length(),
          dateModified = file.lastModified() / 1000,
          duration = metadata.durationMs,
          width = metadata.width,
          height = metadata.height,
          rotation = metadata.rotation,
          fps = metadata.fps,
          hasEmbeddedSubtitles = metadata.hasEmbeddedSubtitles,
          subtitleCodec = metadata.subtitleCodec,
          artist = metadata.artist,
          album = metadata.album,
          lastScanned = System.currentTimeMillis(),
        ),
      )
    }.onFailure { error ->
      Log.w(TAG, "Failed to extract metadata for $displayName: ${error.message}")
    }
    return result.getOrNull()
  }

  /**
   * Walks [files] in priority order, invoking [onResult] with the best metadata
   * available for each file as soon as it is known.
   *
   * Cache lookups and MediaInfo extraction are both batched, but unlike
   * [getOrExtractMetadataBatch] the caller receives results incrementally instead of
   * waiting for the entire list. Cached entries in a batch are reported before the
   * uncached files of that batch are probed, so a warm cache streams out immediately.
   */
  suspend fun walkMetadata(
    files: List<Triple<File, Uri, String>>,
    onResult: (path: String, metadata: VideoMetadata) -> Unit,
  ) = withContext(Dispatchers.IO) {
    if (files.isEmpty()) return@withContext

    files.chunked(PARALLEL_PROCESSING_LIMIT).forEach { chunk ->
      currentCoroutineContext().ensureActive()

      // Batch cache lookup for this chunk only.
      val cachedByPath = dao.getMetadataBatch(chunk.map { it.first.absolutePath })
        .associateBy { it.path }

      val pending = mutableListOf<Triple<File, Uri, String>>()
      for ((file, uri, displayName) in chunk) {
        val cached = cachedByPath[file.absolutePath]
        if (cached != null &&
          cached.dateModified == file.lastModified() / 1000 &&
          cached.size == file.length()
        ) {
          onResult(
            cached.path,
            VideoMetadata(
              sizeBytes = cached.size,
              durationMs = cached.duration,
              width = cached.width,
              height = cached.height,
              rotation = cached.rotation,
              fps = cached.fps,
              hasEmbeddedSubtitles = cached.hasEmbeddedSubtitles,
              subtitleCodec = cached.subtitleCodec,
              artist = cached.artist,
              album = cached.album,
            ),
          )
        } else {
          pending.add(Triple(file, uri, displayName))
        }
      }

      if (pending.isEmpty()) return@forEach

      coroutineScope {
        pending.map { (file, uri, displayName) ->
          async { file.absolutePath to extractAndCache(file, uri, displayName) }
        }.awaitAll().forEach { (path, metadata) ->
          if (metadata != null) onResult(path, metadata)
        }
      }
    }
  }

  /**
   * Cheap, container-probing-free resolution lookup used to pre-filter candidates
   * (e.g. Shorts orientation) before paying for a MediaInfo extraction.
   *
   * Resolution sources, in order: MediaStore columns already present on [Video],
   * then MediaMetadataRetriever, which is significantly faster than MediaInfo on
   * low-end devices and does not need a detached file descriptor.
   * Returns null when no source could determine a landscape/portrait orientation.
   */
  suspend fun probeResolution(video: Video): Pair<Int, Int>? =
    withContext(Dispatchers.IO) {
      val fromStore = resolveOrientation(video.width, video.height, video.rotation)
      if (fromStore != null) return@withContext fromStore

      val retriever = android.media.MediaMetadataRetriever()
      try {
        retriever.setDataSource(video.path)
        val w = retriever
          .extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)
          ?.toIntOrNull() ?: 0
        val h = retriever
          .extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)
          ?.toIntOrNull() ?: 0
        val rotation = retriever
          .extractMetadata(android.media.MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
          ?.toIntOrNull() ?: video.rotation
        resolveOrientation(w, h, rotation)
      } catch (e: Exception) {
        Log.d(TAG, "Resolution probe failed for ${video.displayName}: ${e.message}")
        null
      } finally {
        runCatching { retriever.release() }
      }
    }

  /** Applies display rotation, then reports whether the frame is portrait. */
  private fun resolveOrientation(width: Int, height: Int, rotation: Int): Pair<Int, Int>? {
    if (width <= 0 || height <= 0 || width > RETRIEVER_SAFE_WIDTH || height > RETRIEVER_SAFE_WIDTH) {
      return null
    }
    // 90 / 270 degree rotations swap the displayed axes.
    return if (rotation % 180 == 0) width to height else height to width
  }

  /**
   * Get metadata from cache or extract using MediaInfo
   * Returns immediately with cached data, or suspends to extract if not cached
   */
  suspend fun getOrExtractMetadata(
    file: File,
    uri: Uri,
    displayName: String,
  ): MediaInfoOps.VideoMetadata? =
    withContext(Dispatchers.IO) {
      val path = file.absolutePath
      val size = file.length()
      val dateModified = file.lastModified() / 1000

      // Try cache first
      val cached = dao.getMetadata(path, dateModified, size)
      if (cached != null) {
        Log.d(TAG, "Cache hit for $displayName")
        return@withContext MediaInfoOps.VideoMetadata(
          sizeBytes = cached.size,
          durationMs = cached.duration,
          width = cached.width,
          height = cached.height,
          rotation = cached.rotation,
          fps = cached.fps,
          hasEmbeddedSubtitles = cached.hasEmbeddedSubtitles,
          subtitleCodec = cached.subtitleCodec,
          artist = cached.artist,
          album = cached.album,
        )
      }

      // Cache miss - extract metadata
      Log.d(TAG, "Cache miss for $displayName, extracting metadata")
      val result = MediaInfoOps.extractBasicMetadata(context, uri, displayName)

      result.onSuccess { metadata ->
        // Save to cache
        dao.insertMetadata(
          VideoMetadataEntity(
            path = path,
            size = size,
            dateModified = dateModified,
            duration = metadata.durationMs,
            width = metadata.width,
            height = metadata.height,
            rotation = metadata.rotation,
            fps = metadata.fps,
            hasEmbeddedSubtitles = metadata.hasEmbeddedSubtitles,
            subtitleCodec = metadata.subtitleCodec,
            artist = metadata.artist,
            album = metadata.album,
            lastScanned = System.currentTimeMillis(),
          ),
        )
      }.onFailure { error ->
        Log.w(TAG, "Failed to extract metadata for $displayName: ${error.message}")
      }

      result.getOrNull()
    }

  /**
   * Fast batch lookup of cached metadata directly from database (no MediaInfo extraction)
   */
  suspend fun getCachedMetadataBatch(
    paths: List<String>,
  ): Map<String, MediaInfoOps.VideoMetadata> =
    withContext(Dispatchers.IO) {
      if (paths.isEmpty()) return@withContext emptyMap()
      val cachedEntries = dao.getMetadataBatch(paths)
      cachedEntries.associate { cached ->
        cached.path to MediaInfoOps.VideoMetadata(
          sizeBytes = cached.size,
          durationMs = cached.duration,
          width = cached.width,
          height = cached.height,
          rotation = cached.rotation,
          fps = cached.fps,
          hasEmbeddedSubtitles = cached.hasEmbeddedSubtitles,
          subtitleCodec = cached.subtitleCodec,
          artist = cached.artist,
          album = cached.album,
        )
      }
    }

  /**
   * OPTIMIZED: Batch get metadata from cache or extract using MediaInfo
   * Processes multiple files with batch cache lookup and parallel extraction
   * Returns map of paths to metadata (much faster than individual calls)
   */
  suspend fun getOrExtractMetadataBatch(
    files: List<Triple<File, Uri, String>>,
  ): Map<String, MediaInfoOps.VideoMetadata> =
    withContext(Dispatchers.IO) {
      if (files.isEmpty()) return@withContext emptyMap()

      val results = mutableMapOf<String, MediaInfoOps.VideoMetadata>()

      // Batch lookup from cache
      val paths = files.map { it.first.absolutePath }
      val cachedEntries = dao.getMetadataBatch(paths)
      val cachedMap = cachedEntries.associateBy { it.path }

      // Separate cached and uncached files
      val cachedFiles = mutableListOf<Triple<String, File, VideoMetadataEntity>>()
      val uncachedFiles = mutableListOf<Triple<File, Uri, String>>()

      for ((file, uri, displayName) in files) {
        val path = file.absolutePath
        val size = file.length()
        val dateModified = file.lastModified() / 1000

        val cached = cachedMap[path]
        if (cached != null && cached.dateModified == dateModified && cached.size == size) {
          // Cache hit - valid entry
          cachedFiles.add(Triple(path, file, cached))
        } else {
          // Cache miss or stale entry
          uncachedFiles.add(Triple(file, uri, displayName))
        }
      }

      Log.d(TAG, "Batch lookup: ${cachedFiles.size} cached, ${uncachedFiles.size} need extraction")

      // Add cached results
      for ((path, _, cached) in cachedFiles) {
        results[path] = MediaInfoOps.VideoMetadata(
          sizeBytes = cached.size,
          durationMs = cached.duration,
          width = cached.width,
          height = cached.height,
          rotation = cached.rotation,
          fps = cached.fps,
          hasEmbeddedSubtitles = cached.hasEmbeddedSubtitles,
          subtitleCodec = cached.subtitleCodec,
          artist = cached.artist,
          album = cached.album,
        )
      }

      // Extract metadata for uncached files in parallel
      if (uncachedFiles.isNotEmpty()) {
        val extractedMetadata = mutableListOf<VideoMetadataEntity>()

        uncachedFiles.chunked(PARALLEL_PROCESSING_LIMIT).forEach { batch ->
          coroutineScope {
            val batchResults =
              batch.map { (file, uri, displayName) ->
                async {
                  val path = file.absolutePath
                  val size = file.length()
                  val dateModified = file.lastModified() / 1000

                  val result = MediaInfoOps.extractBasicMetadata(context, uri, displayName)
                  result.onSuccess { metadata ->
                    synchronized(extractedMetadata) {
                      extractedMetadata.add(
                        VideoMetadataEntity(
                          path = path,
                          size = size,
                          dateModified = dateModified,
                          duration = metadata.durationMs,
                          width = metadata.width,
                          height = metadata.height,
                          rotation = metadata.rotation,
                          fps = metadata.fps,
                          hasEmbeddedSubtitles = metadata.hasEmbeddedSubtitles,
                          subtitleCodec = metadata.subtitleCodec,
                          artist = metadata.artist,
                          album = metadata.album,
                          lastScanned = System.currentTimeMillis(),
                        ),
                      )
                    }
                    path to metadata
                  }.onFailure { error ->
                    Log.w(TAG, "Failed to extract metadata for $displayName: ${error.message}")
                  }
                  result.getOrNull()?.let { path to it }
                }
              }.awaitAll().filterNotNull()

            results.putAll(batchResults)
          }
        }

        // Batch insert all extracted metadata into cache
        if (extractedMetadata.isNotEmpty()) {
          dao.insertMetadataBatch(extractedMetadata)
          Log.d(TAG, "Batch inserted ${extractedMetadata.size} metadata entries to cache")
        }
      }

      results
    }

  /**
   * Extract metadata for multiple videos in parallel with progressive updates
   * Emits results as they become available (progressive loading)
   *
   * @param videos List of (File, Uri, DisplayName) triples
   * @return Flow that emits (path, metadata) pairs as each video is processed
   */
  fun extractMetadataProgressively(
    videos: List<Triple<File, Uri, String>>,
  ): Flow<Pair<String, MediaInfoOps.VideoMetadata?>> =
    flow {
      // Process videos in batches to limit concurrent operations
      videos.chunked(PARALLEL_PROCESSING_LIMIT).forEach { batch ->
        coroutineScope {
          val results =
            batch.map { (file, uri, displayName) ->
              async {
                val metadata = getOrExtractMetadata(file, uri, displayName)
                file.absolutePath to metadata
              }
            }.awaitAll()

          // Emit each result as it completes
          results.forEach { result ->
            emit(result)
          }
        }
      }
    }

  /**
   * Batch extract metadata for videos without blocking UI
   * Processes in parallel and returns all results at once
   */
  suspend fun extractMetadataBatch(
    videos: List<Triple<File, Uri, String>>,
  ): Map<String, MediaInfoOps.VideoMetadata> =
    withContext(Dispatchers.IO) {
      val results = mutableMapOf<String, MediaInfoOps.VideoMetadata>()

      videos.chunked(PARALLEL_PROCESSING_LIMIT).forEach { batch ->
        coroutineScope {
          val batchResults =
            batch.map { (file, uri, displayName) ->
              async {
                val metadata = getOrExtractMetadata(file, uri, displayName)
                if (metadata != null) {
                  file.absolutePath to metadata
                } else {
                  null
                }
              }
            }.awaitAll().filterNotNull()

          results.putAll(batchResults)
        }
      }

      results
    }

  /**
   * Clear old cache entries (older than CACHE_VALIDITY_DAYS)
   */
  suspend fun clearOldCache() {
    val cutoffTimestamp = System.currentTimeMillis() - (CACHE_VALIDITY_DAYS * 24 * 60 * 60 * 1000)
    dao.clearOldCache(cutoffTimestamp)
    Log.d(TAG, "Cleared cache entries older than $CACHE_VALIDITY_DAYS days")
  }

  /**
   * Invalidate cache for deleted/moved/renamed videos
   * Checks if cached files still exist and removes stale entries
   */
  suspend fun invalidateStaleEntries() {
    withContext(Dispatchers.IO) {
      val cachedPaths = dao.getAllCachedPaths()
      if (cachedPaths.isEmpty()) return@withContext

      Log.d(TAG, "Validating ${cachedPaths.size} cached entries...")

      val existingPaths = cachedPaths.filter { path ->
        File(path).exists()
      }

      val staleCount = cachedPaths.size - existingPaths.size
      if (staleCount > 0) {
        // Delete entries for non-existent files
        if (existingPaths.isNotEmpty()) {
          // SQLite has a limit on IN clause size, so chunk if needed
          existingPaths.chunked(999).forEach { chunk ->
            dao.deleteStaleEntries(chunk)
          }
        } else {
          // All cached files are gone, clear everything
          dao.clearAll()
        }
        Log.d(TAG, "Removed $staleCount stale cache entries (deleted/moved/renamed videos)")
      } else {
        Log.d(TAG, "No stale entries found")
      }
    }
  }

  /**
   * Invalidate cache for specific video (when deleted/moved/renamed)
   */
  suspend fun invalidateVideo(path: String) {
    withContext(Dispatchers.IO) {
      dao.deleteByPath(path)
      Log.d(TAG, "Invalidated cache for: $path")
    }
  }

  /**
   * Invalidate cache for multiple videos (batch operation)
   */
  suspend fun invalidateVideos(paths: List<String>) {
    withContext(Dispatchers.IO) {
      if (paths.isEmpty()) return@withContext
      dao.deleteByPaths(paths)
      Log.d(TAG, "Invalidated cache for ${paths.size} videos")
    }
  }

  /**
   * Get cache statistics
   */
  suspend fun getCacheStats(): CacheStats =
    withContext(Dispatchers.IO) {
      CacheStats(
        totalEntries = dao.getCacheCount(),
        totalSizeBytes = dao.getTotalCacheSize() ?: 0L,
      )
    }

  /**
   * Clear all cached metadata
   */
  suspend fun clearAll() {
    dao.clearAll()
    Log.d(TAG, "Cleared all cached metadata")
  }

  /**
   * Perform comprehensive cache maintenance
   * - Remove stale entries (deleted/moved files)
   * - Clear old entries (30+ days)
   * Call this periodically (e.g., on app start)
   */
  suspend fun performMaintenance() {
    withContext(Dispatchers.IO) {
      Log.d(TAG, "Starting cache maintenance...")
      val startTime = System.currentTimeMillis()

      // Step 1: Remove stale entries
      invalidateStaleEntries()

      // Step 2: Clear old entries
      clearOldCache()

      val duration = System.currentTimeMillis() - startTime
      val stats = getCacheStats()
      Log.d(
        TAG,
        "Cache maintenance completed in ${duration}ms. " +
          "Entries: ${stats.totalEntries}, Size: ${formatSize(stats.totalSizeBytes)}",
      )
    }
  }

  private fun formatSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB")
    val digitGroups = (kotlin.math.log10(bytes.toDouble()) / kotlin.math.log10(1024.0)).toInt()
    val value = bytes / 1024.0.pow(digitGroups.toDouble())
    return "%.1f %s".format(value, units[digitGroups])
  }

  data class CacheStats(
    val totalEntries: Int,
    val totalSizeBytes: Long,
  )
}
