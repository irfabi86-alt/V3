package xyz.mpv.rex.repository.subtitles

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import kotlinx.serialization.json.JsonObject
import kotlinx.serialization.json.JsonPrimitive
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import xyz.mpv.rex.preferences.SubtitlesPreferences
import xyz.mpv.rex.repository.wyzie.WyzieErrorKind
import xyz.mpv.rex.repository.wyzie.WyzieException
import xyz.mpv.rex.repository.wyzie.WyzieSubtitle
import java.io.IOException
import java.util.SortedMap
import java.util.TreeMap

/**
 * OpenSubtitles.com REST API.
 *
 * Searching needs only the API key. Downloading is quota-limited and OpenSubtitles asks for a
 * logged-in user, so the optional username and password are exchanged for a short-lived token
 * (kept in memory only) before a download link is requested.
 */
internal class OpenSubtitlesProvider(
  private val client: OkHttpClient,
  private val json: Json,
  private val preferences: SubtitlesPreferences,
) : SubtitleProvider {
  override val id = "opensubtitles"
  override val displayName = "OpenSubtitles"

  private class Session(
    val token: String,
    val host: String,
    val cacheKey: String,
    val createdAt: Long,
  )

  private var session: Session? = null

  private val jsonMedia = "application/json".toMediaType()

  override fun isConfigured(): Boolean = preferences.opensubtitlesApiKey.get().isNotBlank()

  // ==================== Search ====================

  override suspend fun search(query: SubtitleQuery): List<WyzieSubtitle> = withContext(Dispatchers.IO) {
    val apiKey = preferences.opensubtitlesApiKey.get().trim()
    if (apiKey.isBlank()) {
      throw WyzieException(WyzieErrorKind.MissingApiKey, "OpenSubtitles API key is missing")
    }
    mapNetworkErrors(displayName) { fetch(apiKey, query) }
  }

  private fun fetch(apiKey: String, query: SubtitleQuery): List<WyzieSubtitle> {
    // OpenSubtitles redirects requests whose parameters are not lower-case and sorted
    // alphabetically, so build them in a sorted map.
    val params: SortedMap<String, String> = TreeMap()
    query.episode?.let { params["episode_number"] = it.toString() }
    if (query.hearingImpaired) params["hearing_impaired"] = "only"
    if (query.imdbId != null) params["imdb_id"] = query.imdbId.removePrefix("tt").removePrefix("TT")
    if (query.languages.isNotEmpty()) {
      params["languages"] = query.languages.map { it.lowercase() }.sorted().joinToString(",")
    }
    if (query.imdbId == null) params["query"] = query.title.lowercase()
    query.season?.let { params["season_number"] = it.toString() }
    if (query.isEpisode) {
      params["type"] = "episode"
    } else {
      query.year?.let { params["year"] = it }
    }

    val url = "https://$DEFAULT_HOST/api/v1/subtitles".toHttpUrlOrNull()?.newBuilder()?.apply {
      params.forEach { (name, value) -> addQueryParameter(name, value) }
    }?.build() ?: throw IOException("Invalid OpenSubtitles URL")

    val request = Request.Builder()
      .url(url)
      .header("Api-Key", apiKey)
      .header("User-Agent", PROVIDER_USER_AGENT)
      .header("Accept", "application/json")
      .build()

    return client.newCall(request).execute().use { response ->
      val body = response.body?.string().orEmpty()
      if (!response.isSuccessful) throw httpFailure(displayName, response.code, body)
      parse(body, query)
    }
  }

  private fun parse(body: String, query: SubtitleQuery): List<WyzieSubtitle> {
    val root = try {
      json.parseToJsonElement(body).asObject()
    } catch (e: Exception) {
      null
    } ?: throw WyzieException(WyzieErrorKind.ServerError, "OpenSubtitles: unexpected response")

    val data = root["data"].asArray() ?: return emptyList()
    return data.mapNotNull { element ->
      val entry = element.asObject() ?: return@mapNotNull null
      val attributes = entry["attributes"].asObject() ?: return@mapNotNull null
      val file = attributes["files"].asArray()?.firstOrNull().asObject() ?: return@mapNotNull null
      val fileId = file["file_id"].asLong() ?: return@mapNotNull null
      val fileName = file["file_name"].asText()
      val rawLanguage = attributes["language"].asText()
      val code = SubtitleLanguages.codeFor(rawLanguage)
      val format = fileName?.substringAfterLast('.', "")?.lowercase()?.takeIf { it in KNOWN_FORMATS }
      val feature = attributes["feature_details"].asObject()

      WyzieSubtitle(
        id = attributes["subtitle_id"].asText() ?: entry["id"].asText(),
        // Not a real address: the download link only exists after an authenticated request.
        url = "opensubtitles://file/$fileId",
        format = format,
        display = SubtitleLanguages.displayFor(code, rawLanguage),
        language = code ?: rawLanguage?.lowercase(),
        media = feature?.get("title").asText() ?: feature?.get("movie_name").asText(),
        isHearingImpaired = attributes["hearing_impaired"].asBool() == true,
        source = displayName,
        release = attributes["release"].asText(),
        fileName = fileName,
        downloadCount = attributes["download_count"].asInt(),
        providerId = id,
        providerRef = fileId.toString(),
        season = query.season,
        episode = query.episode,
      )
    }
  }

  // ==================== Download ====================

  override suspend fun download(subtitle: WyzieSubtitle): DownloadedSubtitle = withContext(Dispatchers.IO) {
    val fileId = subtitle.providerRef?.toLongOrNull()
      ?: throw WyzieException(WyzieErrorKind.ServerError, "OpenSubtitles: missing file id")
    val apiKey = preferences.opensubtitlesApiKey.get().trim()
    if (apiKey.isBlank()) {
      throw WyzieException(WyzieErrorKind.MissingApiKey, "OpenSubtitles API key is missing")
    }

    val bytes = mapNetworkErrors(displayName) {
      val link = requestLink(apiKey, fileId)
      if (!link.startsWith("https://")) {
        throw WyzieException(WyzieErrorKind.ServerError, "OpenSubtitles: unexpected download address")
      }
      fetchBytes(
        client,
        Request.Builder().url(link).header("User-Agent", PROVIDER_USER_AGENT).build(),
        displayName,
      )
    }
    SubtitleArchive.extract(bytes, subtitle.season, subtitle.episode, subtitle.format ?: "srt")
  }

  private fun credentials(): Pair<String, String>? {
    val user = preferences.opensubtitlesUsername.get().trim()
    val pass = preferences.opensubtitlesPassword.get()
    return if (user.isNotBlank() && pass.isNotBlank()) user to pass else null
  }

  private fun requestLink(apiKey: String, fileId: Long): String {
    val creds = credentials()
    try {
      return postDownload(apiKey, fileId, creds)
    } catch (e: WyzieException) {
      // An expired token is the usual cause of a 401 while logged in: log in again once.
      if (e.kind == WyzieErrorKind.InvalidApiKey && creds != null) {
        clearSession()
        return postDownload(apiKey, fileId, creds)
      }
      throw e
    }
  }

  private fun postDownload(apiKey: String, fileId: Long, creds: Pair<String, String>?): String {
    val active = creds?.let { ensureSession(apiKey, it.first, it.second) }
    val host = active?.host ?: DEFAULT_HOST

    val request = Request.Builder()
      .url("https://$host/api/v1/download")
      .header("Api-Key", apiKey)
      .header("User-Agent", PROVIDER_USER_AGENT)
      .header("Accept", "application/json")
      .apply { if (active != null) header("Authorization", "Bearer ${active.token}") }
      .post("""{"file_id":$fileId}""".toRequestBody(jsonMedia))
      .build()

    return client.newCall(request).execute().use { response ->
      val body = response.body?.string().orEmpty()
      if (!response.isSuccessful) {
        val message = runCatching { json.parseToJsonElement(body).asObject()?.get("message").asText() }.getOrNull()
        when (response.code) {
          406 -> throw WyzieException(
            WyzieErrorKind.RateLimited,
            "OpenSubtitles: download quota reached" + (message?.let { ": $it" } ?: ""),
          )
          401 -> throw WyzieException(
            WyzieErrorKind.InvalidApiKey,
            if (active == null) {
              "OpenSubtitles: downloads need your username and password (Settings > Subtitles)"
            } else {
              "OpenSubtitles: login rejected, check username and password"
            },
          )
          else -> throw httpFailure(displayName, response.code, body)
        }
      }
      json.parseToJsonElement(body).asObject()?.get("link").asText()
        ?: throw WyzieException(WyzieErrorKind.ServerError, "OpenSubtitles: no download link returned")
    }
  }

  @Synchronized
  private fun clearSession() {
    session = null
  }

  @Synchronized
  private fun ensureSession(apiKey: String, user: String, pass: String): Session {
    val cacheKey = "$apiKey|$user|${pass.hashCode()}"
    session?.let {
      if (it.cacheKey == cacheKey && System.currentTimeMillis() - it.createdAt < SESSION_TTL_MS) return it
    }

    val credentials = JsonObject(
      mapOf("username" to JsonPrimitive(user), "password" to JsonPrimitive(pass)),
    ).toString()
    val request = Request.Builder()
      .url("https://$DEFAULT_HOST/api/v1/login")
      .header("Api-Key", apiKey)
      .header("User-Agent", PROVIDER_USER_AGENT)
      .header("Accept", "application/json")
      .post(credentials.toRequestBody(jsonMedia))
      .build()

    val created = client.newCall(request).execute().use { response ->
      val body = response.body?.string().orEmpty()
      if (!response.isSuccessful) {
        if (response.code == 401 || response.code == 400) {
          throw WyzieException(
            WyzieErrorKind.InvalidApiKey,
            "OpenSubtitles: login failed, check username and password",
          )
        }
        throw httpFailure(displayName, response.code, body)
      }
      val root = json.parseToJsonElement(body).asObject()
        ?: throw WyzieException(WyzieErrorKind.ServerError, "OpenSubtitles: unexpected login response")
      val token = root["token"].asText()
        ?: throw WyzieException(WyzieErrorKind.ServerError, "OpenSubtitles: login returned no token")
      // VIP accounts are served from another host; only trust hosts that belong to OpenSubtitles.
      val host = root["base_url"].asText()?.takeIf { isHostOrSubdomain("https://$it", "opensubtitles.com") }
        ?: DEFAULT_HOST
      Session(token, host, cacheKey, System.currentTimeMillis())
    }
    session = created
    return created
  }

  private companion object {
    const val DEFAULT_HOST = "api.opensubtitles.com"
    const val SESSION_TTL_MS = 12L * 60 * 60 * 1000
    val KNOWN_FORMATS = setOf("srt", "ass", "ssa", "vtt", "sub")
  }
}
