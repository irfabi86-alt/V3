package xyz.mpv.rex.ui.player.controls.components.sheets

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material3.Button
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import xyz.mpv.rex.R
import xyz.mpv.rex.preferences.PlayerPreferences
import xyz.mpv.rex.preferences.preference.collectAsState
import xyz.mpv.rex.presentation.components.PlayerSheet
import xyz.mpv.rex.presentation.components.SliderItem
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.tween
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.SwitchDefaults
import androidx.compose.ui.draw.scale
import xyz.mpv.rex.ui.theme.spacing
import `is`.xyz.mpv.MPVLib
import org.koin.compose.koinInject

@Composable
fun VideoZoomSheet(
  videoZoom: Float,
  onSetVideoZoom: (Float) -> Unit,
  onResetVideoPan: () -> Unit,
  onDismissRequest: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val playerPreferences = koinInject<PlayerPreferences>()
  val defaultZoom by playerPreferences.defaultVideoZoom.collectAsState()
  val panAndZoomEnabled by playerPreferences.panAndZoomEnabled.collectAsState()
  var zoom by remember { mutableFloatStateOf(videoZoom) }

  val currentOnSetVideoZoom by rememberUpdatedState(onSetVideoZoom)

  LaunchedEffect(Unit) {
    val mpvZoom = MPVLib.getPropertyDouble("video-zoom")?.toFloat() ?: videoZoom
    zoom = mpvZoom
  }

  LaunchedEffect(zoom) {
    currentOnSetVideoZoom(zoom)
  }

  PlayerSheet(onDismissRequest = onDismissRequest) {
    ZoomVideoSheet(
      zoom = zoom,
      defaultZoom = defaultZoom,
      panAndZoomEnabled = panAndZoomEnabled,
      onZoomChange = { newZoom -> zoom = newZoom },
      onSetAsDefault = {
        playerPreferences.defaultVideoZoom.set(zoom)
      },
      onReset = {
        zoom = 0f
        playerPreferences.defaultVideoZoom.set(0f)
        onResetVideoPan()
      },
      onPanAndZoomToggle = { enabled ->
        playerPreferences.panAndZoomEnabled.set(enabled)
        if (!enabled) {
          onResetVideoPan()
        }
      },
      modifier = modifier,
    )
  }
}

@Composable
private fun ZoomVideoSheet(
  zoom: Float,
  defaultZoom: Float,
  panAndZoomEnabled: Boolean,
  onZoomChange: (Float) -> Unit,
  onSetAsDefault: () -> Unit,
  onReset: () -> Unit,
  onPanAndZoomToggle: (Boolean) -> Unit,
  modifier: Modifier = Modifier,
) {
  val isDefault = zoom == defaultZoom
  val isZero = zoom == 0f

  Column(
    modifier =
      modifier
        .fillMaxWidth()
        .verticalScroll(rememberScrollState())
        .padding(vertical = MaterialTheme.spacing.medium),
    verticalArrangement = Arrangement.spacedBy(MaterialTheme.spacing.small),
  ) {
    // Zoom Label and Value
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = MaterialTheme.spacing.medium),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Text(
        text = stringResource(id = R.string.player_sheets_zoom_slider_label),
        style = MaterialTheme.typography.bodyMedium,
      )
      Text(
        text = "%.2fx".format(zoom),
        style = MaterialTheme.typography.headlineMedium,
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
      )
    }

    // Zoom slider with +/- buttons
    Row(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(horizontal = MaterialTheme.spacing.medium),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.spacedBy(MaterialTheme.spacing.small),
    ) {
      FilledTonalIconButton(
        onClick = {
          val newZoom = (zoom - 0.01f).coerceAtLeast(-1f)
          onZoomChange(newZoom)
        },
        modifier = Modifier.size(36.dp),
      ) {
        Icon(Icons.Default.Remove, contentDescription = stringResource(R.string.player_sheets_zoom_decrease), modifier = Modifier.size(18.dp))
      }

      Slider(
        value = zoom,
        onValueChange = onZoomChange,
        valueRange = -1f..3f,
        modifier = Modifier.weight(1f),
      )

      FilledTonalIconButton(
        onClick = {
          val newZoom = (zoom + 0.01f).coerceAtMost(3f)
          onZoomChange(newZoom)
        },
        modifier = Modifier.size(36.dp),
      ) {
        Icon(Icons.Default.Add, contentDescription = stringResource(R.string.player_sheets_zoom_increase), modifier = Modifier.size(18.dp))
      }
    }

    HorizontalDivider(
      modifier = Modifier.padding(horizontal = MaterialTheme.spacing.medium),
      color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f),
    )

    // Pan & Zoom toggle + action buttons
    Column(
      modifier =
        Modifier
          .fillMaxWidth()
          .padding(horizontal = MaterialTheme.spacing.medium),
      verticalArrangement = Arrangement.spacedBy(MaterialTheme.spacing.small),
    ) {
      // Pan & Zoom toggle
      Row(
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Switch(
          checked = panAndZoomEnabled,
          onCheckedChange = onPanAndZoomToggle,
          modifier = Modifier.scale(0.8f),
          thumbContent = {
            Crossfade(
              targetState = panAndZoomEnabled,
              animationSpec = tween(durationMillis = 200),
              label = "SwitchIconAnimation"
            ) { isChecked ->
              if (isChecked) {
                Icon(
                  imageVector = Icons.Filled.Check,
                  contentDescription = null,
                  modifier = Modifier.size(SwitchDefaults.IconSize),
                  tint = MaterialTheme.colorScheme.onPrimaryContainer
                )
              } else {
                Icon(
                  imageVector = Icons.Filled.Close,
                  contentDescription = null,
                  modifier = Modifier.size(SwitchDefaults.IconSize),
                  tint = MaterialTheme.colorScheme.onSurfaceVariant
                )
              }
            }
          }
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
          text = stringResource(R.string.pref_player_gestures_pan_and_zoom),
          style = MaterialTheme.typography.bodyMedium,
          color = if (panAndZoomEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }

      // Action buttons
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
      ) {
        OutlinedButton(
          onClick = onSetAsDefault,
          enabled = !isDefault,
          modifier = Modifier.weight(1f),
        ) {
          Text(stringResource(R.string.set_as_default), style = MaterialTheme.typography.labelMedium)
        }

        Button(
          onClick = onReset,
          enabled = !isZero,
          modifier = Modifier.weight(1f),
        ) {
          Text(stringResource(R.string.generic_reset), style = MaterialTheme.typography.labelMedium)
        }
      }
    }
  }
}
