package xyz.mpv.rex.ui.player.controls.components

import androidx.compose.foundation.layout.Column
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.sp
import org.koin.compose.koinInject
import xyz.mpv.rex.preferences.PlayerPreferences
import xyz.mpv.rex.preferences.preference.collectAsState
import xyz.mpv.rex.utils.media.PlayerTitleFormatter

/**
 * The video title in the player's top bar. Release-style file names are cleaned up: the title
 * on the first line and below it the season and episode (S02E04) for series, or the year for
 * movies. Anything that is not a release name is shown as it was, and the whole cleanup can be
 * switched off in Settings (clean_video_title).
 */
@Composable
fun PlayerTitleText(
  mediaTitle: String?,
  modifier: Modifier = Modifier,
) {
  val raw = mediaTitle.orEmpty()
  val playerPreferences = koinInject<PlayerPreferences>()
  val cleanTitle by playerPreferences.cleanVideoTitle.collectAsState()
  val display = remember(raw, cleanTitle) {
    if (cleanTitle) PlayerTitleFormatter.format(raw) else PlayerTitleFormatter.Display(raw)
  }

  if (display.subtitle == null) {
    Text(
      display.title,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
      style = MaterialTheme.typography.bodyMedium,
      modifier = modifier,
    )
  } else {
    // Tight line heights so both lines fit in the 40dp top-bar controls.
    Column(modifier = modifier) {
      Text(
        display.title,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 17.sp),
      )
      Text(
        display.subtitle,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
        style = MaterialTheme.typography.labelSmall.copy(lineHeight = 13.sp),
        color = LocalContentColor.current.copy(alpha = 0.75f),
      )
    }
  }
}
