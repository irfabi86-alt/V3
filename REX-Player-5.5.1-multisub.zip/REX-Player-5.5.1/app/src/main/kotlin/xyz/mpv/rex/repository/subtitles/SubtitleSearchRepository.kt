package xyz.mpv.rex.repository.subtitles

import android.net.Uri
import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.Json
import okhttp3.OkHttpClient
import xyz.mpv.rex.preferences.SubtitlesPreferences
import xyz.mpv.rex.repository.wyzie.WyzieEpisode
import xyz.mpv.rex.repository.wyzie.WyzieErrorKind
import xyz.mpv.rex.repository.wyzie.WyzieException
import xyz.mpv.rex.repository.wyzie.WyzieSearchRepository
import xyz.mpv.rex.repository.wyzie.WyzieSubtitle
import xyz.mpv.rex.repository.wyzie.WyzieTmdbResult
import xyz.mpv.rex.repository.wyzie.WyzieTvShowDetails

/**
 * Single entry point for online subtitles. Every provider the user has entered a key for
 * (Wyzie, SubDL, OpenSubtitles, SubSource) is searched in parallel and the results are merged.
 *
 * One provider failing does not hide the others' results; the user only sees an error when
 * nothing at all came back.
 *
 * Title lookup, season and episode pickers still come from Wyzie's TMDb proxy, so they are
 * only available when a Wyzie key is set. Without it the sheet searches by title and uses the
 * season and episode parsed from the file name.
 */
class SubtitleSearchRepository(
  private val wyzie: WyzieSearchRepository,
  client: OkHttpClient,
  json: Json,
  private val preferences: SubtitlesPreferences,
) {
  private val providers: List<SubtitleProvider> = listOf(
    SubDlProvider(client, json, preferences),
    OpenSubtitlesProvider(client, json, preferences),
    SubSourceProvider(client, json, preferences),
  )

  private companion object {
    const val TAG = "SubtitleSearchRepository"
    val IMDB_ID = Regex("""tt\d{5,}""", RegexOption.IGNORE_CASE)
  }

  private fun wyzieEnabled(): Boolean = preferences.wyzieApiKey.get().isNotBlank()

  /** True when at least one provider has the credentials it needs. */
  fun hasAnyProvider(): Boolean = wyzieEnabled() || providers.any { it.isConfigured() }

  // ==================== Search ====================

  suspend fun search(
    query: String,
    season: Int? = null,
    episode: Int? = null,
    year: String? = null,
  ): Result<List<WyzieSubtitle>> = withContext(Dispatchers.IO) {
    try {
      val title = wyzie.normalizeSearchQuery(query)
      if (title.isBlank()) return@withContext Result.success(emptyList())

      val useWyzie = wyzieEnabled()
      val active = providers.filter { it.isConfigured() }
      if (!useWyzie && active.isEmpty()) {
        throw WyzieException(
          WyzieErrorKind.MissingApiKey,
          "No subtitle provider is set up. Add an API key in Subtitle Settings.",
        )
      }

      val languages = preferences.subdlLanguages.get()
        .filter { it != "all" }
        .map { it.lowercase() }
      val providerQuery = SubtitleQuery(
        title = title,
        imdbId = title.takeIf { IMDB_ID.matches(it) },
        season = season,
        episode = episode,
        year = year,
        languages = languages,
        hearingImpaired = preferences.wyzieHearingImpaired.get(),
      )

      val outcomes = coroutineScope {
        val jobs = mutableListOf<kotlinx.coroutines.Deferred<Pair<String, Result<List<WyzieSubtitle>>>>>()
        if (useWyzie) {
          jobs.add(
            async {
              "Wyzie" to wyzie.search(query, season, episode, year).map { list ->
                list.map { it.copy(providerId = "wyzie", source = labelWyzieSource(it.source)) }
              }
            },
          )
        }
        active.forEach { provider ->
          jobs.add(
            async {
              provider.displayName to attempt { provider.search(providerQuery) }
            },
          )
        }
        jobs.awaitAll()
      }

      val merged = outcomes.flatMap { it.second.getOrDefault(emptyList()) }
      val failures = outcomes.mapNotNull { (name, result) ->
        result.exceptionOrNull()?.let { name to it }
      }
      failures.forEach { (name, error) -> Log.w(TAG, "$name search failed: ${error.message}") }

      // Partial results are good results. An error is only worth showing when it is the reason
      // the list is empty.
      if (merged.isEmpty() && failures.isNotEmpty()) {
        throw mostUseful(failures.map { it.second })
      }
      Result.success(rank(merged, title))
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Log.e(TAG, "Search failed: ${e.message}", e)
      Result.failure(e)
    }
  }

  private fun labelWyzieSource(upstream: String?): String =
    if (upstream.isNullOrBlank()) "Wyzie" else "Wyzie/$upstream"

  private suspend fun <T> attempt(block: suspend () -> T): Result<T> =
    try {
      Result.success(block())
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Result.failure(e)
    }

  /** Picks the failure that tells the user the most about what to do next. */
  private fun mostUseful(errors: List<Throwable>): Throwable {
    val priority = listOf(
      WyzieErrorKind.InvalidApiKey,
      WyzieErrorKind.RateLimited,
      WyzieErrorKind.NetworkError,
      WyzieErrorKind.ServerError,
    )
    return errors.minByOrNull { error ->
      val kind = (error as? WyzieException)?.kind
      if (kind == null) priority.size else priority.indexOf(kind).let { if (it < 0) priority.size else it }
    } ?: errors.first()
  }

  private fun rank(results: List<WyzieSubtitle>, title: String): List<WyzieSubtitle> {
    val wanted = title.lowercase()
    return results.sortedWith(
      compareByDescending<WyzieSubtitle> { subtitle ->
        val name = subtitle.displayName.lowercase()
        var score = 0
        if (name.contains(wanted)) score += 100
        if (name.contains("720p") || name.contains("1080p") || name.contains("2160p")) score += 50
        if (name.contains("web-dl") || name.contains("webrip") || name.contains("bluray")) score += 40
        if (name.contains("yify") || name.contains("sparks") || name.contains("rarbg")) score += 30
        score
      }.thenByDescending { it.downloadCount ?: 0 },
    )
  }

  // ==================== Download ====================

  suspend fun download(subtitle: WyzieSubtitle, mediaTitle: String): Result<Uri> = withContext(Dispatchers.IO) {
    val provider = providers.firstOrNull { it.id == subtitle.providerId }
      ?: return@withContext wyzie.download(subtitle, mediaTitle)
    try {
      val file = provider.download(subtitle)
      Result.success(wyzie.saveSubtitleBytes(file.bytes, subtitle.language ?: "en", file.extension, mediaTitle))
    } catch (e: CancellationException) {
      throw e
    } catch (e: Exception) {
      Log.e(TAG, "${provider.displayName} download failed: ${e.message}", e)
      Result.failure(e)
    }
  }

  // ==================== Wyzie-only features (TMDb lookups) ====================

  /**
   * Title suggestions come from Wyzie's TMDb proxy. Without a Wyzie key there are simply no
   * suggestions; this must not be reported as an error because searching by title still works.
   */
  suspend fun searchMedia(query: String): Result<List<WyzieTmdbResult>> =
    if (wyzieEnabled()) wyzie.searchMedia(query) else Result.success(emptyList())

  suspend fun getTvShowDetails(id: Int): Result<WyzieTvShowDetails> = wyzie.getTvShowDetails(id)

  suspend fun getSeasonEpisodes(id: Int, season: Int): Result<List<WyzieEpisode>> =
    wyzie.getSeasonEpisodes(id, season)

  suspend fun deleteSubtitleFile(uri: Uri): Boolean = wyzie.deleteSubtitleFile(uri)
}
