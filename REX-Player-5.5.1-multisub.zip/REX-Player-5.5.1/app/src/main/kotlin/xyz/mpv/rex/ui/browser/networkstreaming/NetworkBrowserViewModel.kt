package xyz.mpv.rex.ui.browser.networkstreaming

import android.app.Application
import android.content.Intent
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import xyz.mpv.rex.domain.network.NetworkConnection
import xyz.mpv.rex.domain.network.NetworkFile
import xyz.mpv.rex.domain.network.NetworkProtocol
import xyz.mpv.rex.preferences.BrowserPreferences
import xyz.mpv.rex.repository.NetworkRepository
import xyz.mpv.rex.ui.browser.base.BaseBrowserViewModel
import xyz.mpv.rex.utils.media.FolderPlaylistOps
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.drop
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.koin.core.component.KoinComponent
import org.koin.core.component.inject

/**
 * ViewModel for browsing files on a network share
 * Follows MVVM pattern with proper separation of concerns
 */
class NetworkBrowserViewModel(
  private val application: Application,
  private val connectionId: Long,
  private val currentPath: String,
) : BaseBrowserViewModel<NetworkFile>(application),
  KoinComponent {
  private val repository: NetworkRepository by inject()

  private val _error = MutableStateFlow<String?>(null)
  val error: StateFlow<String?> = _error.asStateFlow()

  init {
    viewModelScope.launch(Dispatchers.Default) {
      combine(
        browserPreferences.networkSortType.changes(),
        browserPreferences.networkSortOrder.changes(),
      ) { _, _ -> }
        .drop(1)
        .collect {
          _items.update { it.sortedWith(listComparator()) }
        }
    }
  }
  /**
   * Load files in the current directory
   */
  override fun loadData() {
    viewModelScope.launch {
      _isLoading.value = true
      _error.value = null

      try {
        val connection = repository.getConnectionById(connectionId)
          ?: throw Exception("Connection not found")

        repository.listFiles(connection, currentPath)
          .onSuccess { fileList ->
            _items.value = fileList.sortedWith(listComparator())
          }
          .onFailure { e ->
            _error.value = e.message ?: "Unknown error"
          }
      } catch (e: Exception) {
        _error.value = e.message ?: "Unknown error"
      } finally {
        _isLoading.value = false
      }
    }
  }

  override fun refresh(silent: Boolean) {
    loadData()
  }

  /** Directories first, then the network browser's sort preference. */
  private fun listComparator(): Comparator<NetworkFile> =
    compareBy<NetworkFile> { !it.isDirectory }.then(FolderPlaylistOps.networkFileComparator())

  /**
   * Play a video file
   */
  fun playVideo(file: NetworkFile) {
    viewModelScope.launch {
      try {
        val connection = repository.getConnectionById(connectionId)
          ?: throw Exception("Connection not found")

        // Use proxy server for protocols that need seeking support
        val useProxy = connection.protocol in PROXY_PROTOCOLS

        val uri = if (useProxy) {
          val proxy = xyz.mpv.rex.ui.browser.networkstreaming.proxy.NetworkStreamingProxy.getInstance()
            ?: throw IllegalStateException("Local proxy unavailable; network playback requires the Network permission")
          val streamId = "${connectionId}_${System.currentTimeMillis()}"
          val proxyUrl = proxy.registerStream(
            streamId = streamId,
            connection = connection,
            filePath = file.path,
            fileSize = file.size,
            mimeType = file.mimeType ?: "video/mp4",
          )
          android.net.Uri.parse(proxyUrl)
        } else {
          NetworkStreamingProvider.setConnection(connectionId, connection)
          NetworkStreamingProvider.getUri(application, connectionId, file.path)
        }

        // Launch the player
        val intent = Intent(Intent.ACTION_VIEW, uri)
        intent.setClass(application, xyz.mpv.rex.ui.player.PlayerActivity::class.java)
        intent.putExtra("internal_launch", true)
        intent.putExtra("launch_source", "network_stream")
        intent.putExtra("title", file.name)
        intent.putExtra("filename", file.name)
        // Pass the original network file path for stable media identifier (position saving)
        intent.putExtra("network_file_path", file.path)
        intent.putExtra("network_connection_id", connectionId)
        intent.setDataAndType(uri, file.mimeType ?: "video/*")
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)

        if (!useProxy) {
          intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }

        application.startActivity(intent)
      } catch (e: Exception) {
        Log.e(TAG, "Error playing video", e)
        _error.value = e.message ?: "Unknown error"
      }
    }
  }

  companion object {
    private const val TAG = "NetworkBrowserVM"

    // Protocols that require proxy server for seeking support
    private val PROXY_PROTOCOLS = setOf(
      NetworkProtocol.SMB,
      NetworkProtocol.FTP,
      NetworkProtocol.WEBDAV,
    )

    fun factory(
      application: Application,
      connectionId: Long,
      currentPath: String,
    ): ViewModelProvider.Factory =
      viewModelFactory {
        initializer {
          NetworkBrowserViewModel(application, connectionId, currentPath)
        }
      }
  }
}
