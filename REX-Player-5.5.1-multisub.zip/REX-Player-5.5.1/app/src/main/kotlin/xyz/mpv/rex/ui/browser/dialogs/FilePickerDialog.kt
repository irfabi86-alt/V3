package xyz.mpv.rex.ui.browser.dialogs

import android.content.Context
import android.content.res.Configuration
import android.os.Environment
import androidx.compose.foundation.MarqueeAnimationMode
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.InsertDriveFile
import androidx.compose.material.icons.filled.DriveFolderUpload
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.SdCard
import androidx.compose.material.icons.filled.Usb
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.FilledTonalIconButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.res.stringResource
import xyz.mpv.rex.R
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.draw.clip
import androidx.compose.foundation.background
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import xyz.mpv.rex.utils.storage.StorageVolumeUtils
import java.io.File

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
fun FilePickerDialog(
  modifier: Modifier = Modifier,
  isOpen: Boolean,
  title: String = "Select Subtitle",
  currentPath: String = Environment.getExternalStorageDirectory().absolutePath,
  onDismiss: () -> Unit,
  onFileSelected: (String) -> Unit,
  onPathChanged: ((String?) -> Unit)? = null,
  onSystemPickerRequest: () -> Unit,
  matchToName: String? = null,
  allowedExtensions: List<String> = listOf(
    // Common & modern
    "srt", "vtt", "ass", "ssa",

    // DVD / Blu-ray
    "sub", "idx", "sup",

    // Streaming / XML / Professional
    "xml", "ttml", "dfxp", "itt", "ebu", "imsc", "usf",

    // Online platforms
    "sbv", "srv1", "srv2", "srv3", "json",

    // Legacy & niche
    "sami", "smi", "mpl", "pjs", "stl", "rt", "psb", "cap",

    // Broadcast captions
    "scc", "vttx",

    // Karaoke / lyrics
    "lrc", "krc",

    // Fallback / raw text
    "txt"
  ),

  // Multi-select mode (opt-in, used by "Add Font File"): tapping a file toggles its selection instead of choosing it
  // right away, and nothing is returned until the user confirms with the import button. With the default
  // (false) the dialog behaves exactly as before and [onFilesSelected] is never used. Declared last so the
  // position of every older parameter is unchanged.
  multiSelect: Boolean = false,
  onFilesSelected: ((List<String>) -> Unit)? = null,
) {
  if (!isOpen) return

  val context = LocalContext.current
  
  // Get all available storage volumes
  val storageVolumes = remember(isOpen) {
    StorageVolumeUtils.getAllStorageVolumes(context)
  }
  
  // If there's only one storage volume, start there directly
  // Otherwise, start at storage root view to show all volumes
  // Respect currentPath if it's valid and exists
  var selectedPath by remember(isOpen, currentPath, storageVolumes) {
    val initialPath = if (currentPath.isNotEmpty() && File(currentPath).exists()) {
      currentPath
    } else if (storageVolumes.size == 1) {
      StorageVolumeUtils.getVolumePath(storageVolumes.first())
    } else {
      null // Show storage root with all volumes
    }
    mutableStateOf(initialPath)
  }

  // Selected files (multi-select mode only), in selection order; kept while browsing between folders.
  var selectedFiles by remember(isOpen) { mutableStateOf(emptyList<String>()) }
  // Set by the first confirmation: the import button (and the selection) are inert from then on, so a double tap can
  // never confirm the same batch twice while the parent is still closing the dialog.
  var confirmed by remember(isOpen) { mutableStateOf(false) }

  // Notify parent when path changes for state persistence
  LaunchedEffect(selectedPath) {
    onPathChanged?.invoke(selectedPath)
  }

  // Determine what to show based on selectedPath
  val showStorageRoot = selectedPath == null
  
  val currentDir = remember(selectedPath) { 
    selectedPath?.let { File(it) }
  }
  
  // Get folders and allowed files
  val (folders, files) = remember(selectedPath, matchToName) {
    if (showStorageRoot) {
      Pair(emptyList<File>(), emptyList<File>())
    } else {
      val allFiles = currentDir?.listFiles { file -> !file.name.startsWith(".") } ?: emptyArray()
      
      // Use NaturalOrderComparator for better sorting (e.g., Ep 2 < Ep 10)
      val dirs = allFiles.filter { it.isDirectory }.sortedWith { f1, f2 -> 
          xyz.mpv.rex.utils.sort.SortUtils.NaturalOrderComparator.DEFAULT.compare(f1.name, f2.name)
      }
      
      val filteredFiles = allFiles.filter { file -> 
          !file.isDirectory && allowedExtensions.any { ext -> file.name.endsWith(ext, ignoreCase = true) } 
      }

      // Final sorted files: matches first (alphabetical), then others (alphabetical)
      val finalSortedFiles = filteredFiles.sortedWith { f1, f2 ->
          val m1 = matchToName != null && f1.name.contains(matchToName, ignoreCase = true)
          val m2 = matchToName != null && f2.name.contains(matchToName, ignoreCase = true)
          
          if (m1 && !m2) {
              -1
          } else if (!m1 && m2) {
              1
          } else {
              xyz.mpv.rex.utils.sort.SortUtils.NaturalOrderComparator.DEFAULT.compare(f1.name, f2.name)
          }
      }
      
      Pair(dirs, finalSortedFiles)
    }
  }

  val configuration = LocalConfiguration.current
  val isPortrait = configuration.orientation == Configuration.ORIENTATION_PORTRAIT

  androidx.compose.ui.window.Dialog(
    onDismissRequest = onDismiss,
    properties = DialogProperties(usePlatformDefaultWidth = false),
  ) {
      Surface(
          modifier = modifier.fillMaxWidth(if (isPortrait) 0.9f else 0.50f),
          shape = MaterialTheme.shapes.extraLarge,
          color = MaterialTheme.colorScheme.surface,
          tonalElevation = 6.dp,
      ) {
          Column(
              modifier = Modifier.padding(24.dp),
              verticalArrangement = Arrangement.spacedBy(16.dp)
          ) {
              // Title Section - orientation-aware layout
              if (isPortrait) {
                // Portrait: title/path stacked on top, nav buttons centered below
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  Column(modifier = Modifier.fillMaxWidth()) {
                      Text(
                        text = title,
                        style = MaterialTheme.typography.headlineSmall,
                        fontWeight = FontWeight.Bold,
                      )
                      Text(
                        text = selectedPath ?: stringResource(R.string.select_storage_location),
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Medium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.padding(top = 4.dp),
                      )
                  }
                  Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterHorizontally),
                  ) {
                    NavigationButtons(
                      selectedPath = selectedPath,
                      onBack = { selectedPath = currentDir?.parent },
                      onHome = { selectedPath = Environment.getExternalStorageDirectory().absolutePath },
                      onSystemPicker = onSystemPickerRequest,
                      buttonSize = 48.dp,
                      iconSize = 26.dp,
                    )
                  }
                }
              } else {
                // Landscape: title/path left, nav buttons right (same row)
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                  Row(
                      modifier = Modifier.fillMaxWidth(),
                      horizontalArrangement = Arrangement.SpaceBetween,
                      verticalAlignment = Alignment.CenterVertically
                  ) {
                      Column(modifier = Modifier.weight(1f)) {
                           Text(
                             text = title,
                             style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Bold,
                          )
                          Text(
                            text = selectedPath ?: stringResource(R.string.select_storage_location),
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Medium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.padding(top = 4.dp),
                          )
                      }
                      Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        NavigationButtons(
                          selectedPath = selectedPath,
                          onBack = { selectedPath = currentDir?.parent },
                          onHome = { selectedPath = Environment.getExternalStorageDirectory().absolutePath },
                          onSystemPicker = onSystemPickerRequest,
                          buttonSize = 40.dp,
                          iconSize = 24.dp,
                        )
                      }
                  }
                }
              }

              // Content Section
              Column(
                modifier =
                  if (multiSelect) {
                    // The header and the footer (with the Import button) are measured first; the list gets what is
                    // left, up to the usual 400.dp. A fixed 400.dp list pushed the footer out of the window on
                    // landscape / short screens, so the confirmation button could not be seen or tapped.
                    Modifier.fillMaxWidth().weight(1f).heightIn(max = 400.dp)
                  } else {
                    Modifier.fillMaxWidth()
                  },
                verticalArrangement = Arrangement.spacedBy(16.dp),
              ) {
                // Folder/Volume/File list
                LazyColumn(
                  modifier =
                    if (multiSelect) {
                      Modifier.fillMaxSize()
                    } else {
                      Modifier
                        .fillMaxWidth()
                        .height(400.dp)
                    },
                  verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                  if (showStorageRoot) {
                    // Show storage volumes
                    items(storageVolumes) { volume ->
                      val volumePath = StorageVolumeUtils.getVolumePath(volume)
                      if (volumePath != null) {
                        StorageVolumeItem(
                          context = context,
                          volume = volume,
                          volumePath = volumePath,
                          onClick = { selectedPath = volumePath },
                        )
                      }
                    }
                    if (storageVolumes.isEmpty()) {
                      item {
                         Text(stringResource(R.string.no_storage_devices_found), modifier = Modifier.padding(16.dp))
                      }
                    }
                  } else {
                    // Show folders
                    items(folders) { folder ->
                      FolderItem(
                        folder = folder,
                        onClick = { selectedPath = folder.absolutePath },
                      )
                    }
                    // Show files
                    items(files) { file ->
                        FileItem(
                            file = file,
                            selectionMode = multiSelect,
                            selected = file.absolutePath in selectedFiles,
                            onClick = {
                              if (multiSelect) {
                                if (!confirmed) {
                                  val path = file.absolutePath
                                  selectedFiles = if (path in selectedFiles) selectedFiles - path else selectedFiles + path
                                }
                              } else {
                                onFileSelected(file.absolutePath)
                              }
                            }
                        )
                    }
                    if (folders.isEmpty() && files.isEmpty()) {
                      item {
                         Text(stringResource(R.string.no_folders_or_supported_files), modifier = Modifier.padding(16.dp))
                      }
                    }
                  }
                }
              }

              // Footer Section (Analyze padding here)
              if (multiSelect) {
                // Three actions may not fit side by side on a narrow screen or with longer (e.g. Arabic) labels, so
                // they wrap onto a second line instead of overlapping or leaving the dialog.
                FlowRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.End),
                    verticalArrangement = Arrangement.spacedBy(4.dp),
                ) {
                    if (selectedFiles.isNotEmpty()) {
                      TextButton(
                        onClick = { selectedFiles = emptyList() },
                        shape = MaterialTheme.shapes.extraLarge,
                      ) {
                        Text(stringResource(R.string.file_picker_clear_selection), fontWeight = FontWeight.Medium)
                      }
                    }
                    TextButton(
                      onClick = onDismiss,
                      shape = MaterialTheme.shapes.extraLarge,
                    ) {
                      Text(stringResource(R.string.generic_cancel), fontWeight = FontWeight.Medium)
                    }
                    Button(
                      onClick = {
                        if (!confirmed) {
                          confirmed = true
                          onFilesSelected?.invoke(selectedFiles)
                        }
                      },
                      enabled = !confirmed && selectedFiles.isNotEmpty() && onFilesSelected != null,
                      shape = MaterialTheme.shapes.extraLarge,
                    ) {
                      Text(
                        stringResource(R.string.file_picker_import_selected, selectedFiles.size),
                        fontWeight = FontWeight.Medium,
                      )
                    }
                }
              } else {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(
                      onClick = onDismiss,
                      shape = MaterialTheme.shapes.extraLarge,
                      // Reduced padding for the button itself if needed, or rely on Row padding
                    ) {
                      Text(stringResource(R.string.generic_cancel), fontWeight = FontWeight.Medium)
                    }
                }
              }
          }
      }
  }
}

@Composable
private fun StorageVolumeItem(
  context: Context,
  volume: android.os.storage.StorageVolume,
  volumePath: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val description = volume.getDescription(context)
  val isPrimary = volume.isPrimary
  val isRemovable = volume.isRemovable
  
  val icon = when {
    isPrimary -> Icons.Default.Home
    isRemovable && volumePath.contains("usb", ignoreCase = true) -> Icons.Default.Usb
    isRemovable -> Icons.Default.SdCard
    else -> Icons.Default.Folder
  }
  
  Row(
    modifier =
      modifier
        .fillMaxWidth()
        .clickable(onClick = onClick)
        .padding(horizontal = 12.dp, vertical = 12.dp),
    horizontalArrangement = Arrangement.spacedBy(12.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = null,
      tint = MaterialTheme.colorScheme.primary,
      modifier = Modifier.size(32.dp),
    )
    Column(
      verticalArrangement = Arrangement.spacedBy(2.dp),
    ) {
      Text(
        text = description,
        style = MaterialTheme.typography.bodyLarge,
        fontWeight = FontWeight.Bold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
      Text(
        text = volumePath,
        style = MaterialTheme.typography.bodyMedium,
        fontWeight = FontWeight.Medium,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
      )
    }
  }
}

@Composable
private fun FolderItem(
  folder: File,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier =
      modifier
        .fillMaxWidth()
        .clickable(onClick = onClick)
        .padding(horizontal = 12.dp, vertical = 8.dp),
    horizontalArrangement = Arrangement.spacedBy(12.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Icon(
      imageVector = Icons.Default.Folder,
      contentDescription = null,
      tint = MaterialTheme.colorScheme.primary,
      modifier = Modifier.size(28.dp),
    )
    Text(
      text = folder.name,
      style = MaterialTheme.typography.bodyLarge,
      fontWeight = FontWeight.Medium,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
      modifier = Modifier.basicMarquee(
        animationMode = MarqueeAnimationMode.Immediately,
        repeatDelayMillis = 2000,
      ),
    )
  }
}

@Composable
private fun FileItem(
  file: File,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
  selectionMode: Boolean = false,
  selected: Boolean = false,
) {
  Row(
    modifier =
      modifier
        .fillMaxWidth()
        .then(
          if (selected) {
            Modifier.clip(MaterialTheme.shapes.medium).background(MaterialTheme.colorScheme.secondaryContainer)
          } else {
            Modifier
          },
        )
        .clickable(onClick = onClick)
        .padding(horizontal = 12.dp, vertical = 8.dp),
    horizontalArrangement = Arrangement.spacedBy(12.dp),
    verticalAlignment = Alignment.CenterVertically,
  ) {
    if (selectionMode) {
      // Visual indicator only: the whole row toggles the selection.
      Checkbox(checked = selected, onCheckedChange = null)
    }
    Icon(
      imageVector = Icons.AutoMirrored.Filled.InsertDriveFile,
      contentDescription = null,
      tint = MaterialTheme.colorScheme.secondary,
      modifier = Modifier.size(28.dp),
    )
    Text(
      text = file.name,
      style = MaterialTheme.typography.bodyLarge,
      fontWeight = FontWeight.Normal,
      maxLines = 1,
      overflow = TextOverflow.Ellipsis,
      modifier = Modifier.basicMarquee(
        animationMode = MarqueeAnimationMode.Immediately,
        repeatDelayMillis = 2000,
      ),
    )
  }
}

@OptIn(ExperimentalMaterial3ExpressiveApi::class)
@Composable
private fun NavigationButtons(
  selectedPath: String?,
  onBack: () -> Unit,
  onHome: () -> Unit,
  onSystemPicker: () -> Unit,
  buttonSize: Dp,
  iconSize: Dp,
) {
  if (selectedPath != null) {
    FilledTonalIconButton(
      onClick = onBack,
      modifier = Modifier.size(buttonSize),
      colors = IconButtonDefaults.filledTonalIconButtonColors(
        containerColor = MaterialTheme.colorScheme.secondaryContainer,
        contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
      )
    ) {
      Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", modifier = Modifier.size(iconSize))
    }
  }

  FilledTonalIconButton(
    onClick = onHome,
    modifier = Modifier.size(buttonSize),
    colors = IconButtonDefaults.filledTonalIconButtonColors(
      containerColor = MaterialTheme.colorScheme.secondaryContainer,
      contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
    )
  ) {
    Icon(Icons.Default.Home, "Home", modifier = Modifier.size(iconSize))
  }

  FilledTonalIconButton(
    onClick = onSystemPicker,
    modifier = Modifier.size(buttonSize),
    colors = IconButtonDefaults.filledTonalIconButtonColors(
      containerColor = MaterialTheme.colorScheme.secondaryContainer,
      contentColor = MaterialTheme.colorScheme.onSecondaryContainer,
    )
  ) {
    Icon(Icons.Default.DriveFolderUpload, "System Picker", modifier = Modifier.size(iconSize))
  }
}

