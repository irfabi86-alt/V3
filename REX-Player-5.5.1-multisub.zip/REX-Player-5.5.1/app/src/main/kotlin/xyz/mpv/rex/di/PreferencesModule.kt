package xyz.mpv.rex.di

import xyz.mpv.rex.database.MpvExDatabase
import xyz.mpv.rex.domain.pinned.PinnedItemRepository
import xyz.mpv.rex.domain.pinned.PinnedItemRepositoryImpl
import xyz.mpv.rex.preferences.AdvancedPreferences
import xyz.mpv.rex.preferences.AppearancePreferences
import xyz.mpv.rex.preferences.AudioPreferences
import xyz.mpv.rex.preferences.BrowserPreferences
import xyz.mpv.rex.preferences.DecoderPreferences
import xyz.mpv.rex.preferences.FoldersPreferences
import xyz.mpv.rex.preferences.GesturePreferences
import xyz.mpv.rex.preferences.PlayerPreferences
import xyz.mpv.rex.preferences.SettingsManager
import xyz.mpv.rex.preferences.SubtitlesPreferences
import xyz.mpv.rex.preferences.UiPreferences
import xyz.mpv.rex.preferences.YtdlPreferences
import xyz.mpv.rex.ui.player.PlayerTutorialManager
import xyz.mpv.rex.jellyfin.preferences.JellyfinPreferences
import xyz.mpv.rex.preferences.preference.AndroidPreferenceStore
import xyz.mpv.rex.preferences.preference.PreferenceStore
import org.koin.android.ext.koin.androidContext
import org.koin.core.module.dsl.singleOf
import org.koin.dsl.bind
import org.koin.dsl.module

val PreferencesModule =
  module {
    single { JellyfinPreferences(androidContext()) }
    single { AndroidPreferenceStore(androidContext()) }.bind(PreferenceStore::class)

    single { AppearancePreferences(get()) }
    singleOf(::PlayerPreferences)
    singleOf(::GesturePreferences)
    singleOf(::DecoderPreferences)
    singleOf(::SubtitlesPreferences)
    singleOf(::AudioPreferences)
    singleOf(::AdvancedPreferences)
    single { BrowserPreferences(get(), androidContext()) }
    singleOf(::FoldersPreferences)
    single<PinnedItemRepository> { PinnedItemRepositoryImpl(get()) }
    singleOf(::SettingsManager)
    singleOf(::UiPreferences)
    singleOf(::PlayerTutorialManager)
    singleOf(::YtdlPreferences)
  }
